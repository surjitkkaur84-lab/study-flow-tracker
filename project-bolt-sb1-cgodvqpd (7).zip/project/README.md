# StudyFlow - Student Study Productivity App

🌐 **Live Demo**: [View StudyFlow App](https://yourusername.github.io/studyflow/)

A beautiful and feature-rich study productivity application designed specifically for college students doing extra online study. Seamlessly combines study task management with the Pomodoro time management technique, enhanced with academic-focused features. Built with React, TypeScript, and Tailwind CSS.

## 🚀 Quick Deploy to GitHub Pages

1. Fork this repository
2. Clone to your local machine
3. Run `npm install`
4. Run `npm run deploy`
5. Enable GitHub Pages in repository settings

## ✨ Features

### 📚 Academic Study Timer Integration
- **Study-focused timer** with book-themed visual design and animations
- **Study/Break/Long-break cycle automation** with customizable durations
- **Visual progress indicators** with smooth animations
- **Sound notifications** for phase completions
- **Task-specific timers** - click the study icon next to any task to start focused study sessions
- **Long break intervals** - automatically suggests longer breaks after multiple study sessions

### 📝 Advanced Study Task Management
- **Add, edit, and delete study tasks** with comprehensive details
- **Subject categorization** - organize tasks by academic subjects
- **Study type classification** - reading, practice, research, review, assignments, exam prep
- **Priority levels** - high, medium, low with visual indicators
- **Difficulty ratings** - easy, medium, hard with star indicators
- **Estimated study sessions** - plan your study time effectively
- **Due date tracking** - never miss important deadlines
- **Drag-and-drop reordering** for easy task prioritization
- **Task completion tracking** with visual feedback
- **Study session count per task** to track focused study time
- **Separate completed tasks section** for better organization

### 📊 Progress Dashboard
- **Daily statistics** showing study tasks completed and study sessions finished
- **Visual progress charts** with animated circular progress indicators
- **Study goal tracking** with customizable daily targets
- **Study insights** - total study time, daily streaks, average session length
- **Subject-specific statistics** to track performance across different areas

### ⚙️ Comprehensive Settings
- **Customizable study/break durations** (1-60 minutes for study, 1-30 for short breaks)
- **Long break settings** - duration and interval customization
- **Daily study goals** - set and track your daily session targets
- **Theme selection** - Academic Blue, Forest Green, Ocean Teal, or Midnight Dark
- **Auto-start break option** for seamless workflow
- **Auto-start long break option** for extended rest periods
- **Sound notification toggle** for different work environments
- **Browser notification support** for study reminders
- **Keyboard shortcut preferences**

### ⌨️ Keyboard Shortcuts
- **Space**: Start/pause the current timer
- **T**: Toggle timer modal
- **S**: Open settings
- **Escape**: Close any open modal

### 💾 Data Persistence
- **Local storage integration** - all study tasks, settings, and progress are automatically saved
- **Restore on reload** - pick up exactly where you left off
- **No account required** - works completely offline

### 🎓 Student-Focused Features
- **Subject organization** - track study time across different courses
- **Academic terminology** - uses student-friendly language throughout
- **Study type categorization** - tailored for different learning activities
- **Deadline management** - visual indicators for overdue and upcoming tasks
- **Session planning** - estimate and track study sessions per task
- **Academic themes** - color schemes designed for focused studying

## 🚀 Getting Started

### Prerequisites
- Node.js (version 14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd studyflow
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to the local development URL (typically `http://localhost:5173`)

### Building for Production

```bash
npm run build
```

The built application will be available in the `dist` directory.

## 🎨 Design Philosophy

StudyFlow follows modern design principles with:

- **Academic-focused aesthetics** with attention to detail and student-friendly design
- **Calming color palette** using blues for study time, greens for breaks, and purples for long breaks
- **Smooth micro-interactions** and hover states for enhanced user experience
- **Responsive design** optimized for both desktop and mobile devices
- **Accessibility-focused** with proper ARIA labels, keyboard navigation, and color contrast
- **Student-centric UI** with academic terminology and study-focused iconography

## 🛠️ Technical Architecture

### Technology Stack
- **React 18** with functional components and hooks
- **TypeScript** for type safety and better developer experience
- **Tailwind CSS** for utility-first styling and responsive design
- **Vite** for fast development and optimized builds
- **Context API** for global state management
- **HTML5 Drag and Drop API** for task reordering

### Project Structure
```
src/
├── components/          # Reusable UI components
│   ├── common/         # Shared components (Modal, Button, etc.)
│   ├── Dashboard/      # Progress tracking components
│   ├── Layout/         # App structure components
│   ├── PomodoroTimer/  # Study timer-related components
│   ├── Settings/       # Settings and preferences
│   └── TodoList/       # Study task management components
├── context/            # React Context providers
├── hooks/              # Custom React hooks
├── types/              # TypeScript type definitions
├── utils/              # Utility functions and helpers
└── styles/             # Global styles and Tailwind config
```

### Key Features Implementation

#### State Management
- Uses React Context API with useReducer for predictable state updates
- Organized actions for all user interactions
- Automatic persistence to localStorage

#### Timer System
- Custom `useTimer` hook manages interval-based countdown
- Automatic phase transitions including long breaks
- Session counting for long break intervals
- Sound notifications using Web Audio API

#### Drag and Drop
- Custom `useDragAndDrop` hook with HTML5 Drag and Drop API
- Visual feedback during drag operations
- Smooth reordering animations

#### Responsive Design
- Mobile-first approach with Tailwind CSS breakpoints
- Touch-friendly interfaces for mobile devices
- Optimized layouts for different screen sizes

#### Academic Features
- Subject and study type categorization
- Priority and difficulty tracking
- Due date management with visual indicators
- Comprehensive task metadata for academic planning

## 🔧 Customization

### Adding New Themes
1. Update the `themes` array in `src/components/Settings/ThemeSelector.tsx`
2. Add corresponding Tailwind CSS classes
3. The theme will automatically appear in the settings

### Adding New Study Types
1. Update the `studyTypes` array in `src/components/TodoList/AddTaskForm.tsx`
2. Add corresponding icons and labels
3. Update the `getStudyTypeIcon` function in `TaskItem.tsx`

### Adding New Subjects
1. Update the `subjects` array in `src/components/TodoList/AddTaskForm.tsx`
2. New subjects will automatically appear in the dropdown

### Modifying Timer Durations
- Default durations can be changed in `src/context/AppContext.tsx`
- Users can customize durations through the settings panel
- Long break intervals and durations are fully customizable
- All changes persist automatically

### Sound Customization
- Modify `src/utils/sound.ts` to change notification sounds
- Add new sound types for different events
- Sounds use Web Audio API for broad compatibility

## 📱 Mobile Experience

StudyFlow is fully optimized for mobile devices:
- **Touch-friendly interfaces** with appropriately sized touch targets
- **Responsive timer display** that scales beautifully on small screens
- **Mobile-optimized modals** that work well on touch devices
- **Gesture support** for task management and navigation
- **Academic-focused mobile UI** optimized for student workflows

## 🎓 Perfect for Students

StudyFlow is specifically designed for college students who are:
- **Taking online courses** alongside regular college work
- **Self-studying** additional subjects or skills
- **Preparing for exams** with structured study sessions
- **Managing multiple subjects** with different priorities
- **Working on assignments** with specific deadlines
- **Building consistent study habits** with goal tracking

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Pomodoro Technique® created by Francesco Cirillo
- Design inspiration from modern academic and productivity applications
- Built with modern React best practices and patterns
- Tailored specifically for the needs of college students and online learners