import React, { useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import { Header } from './components/Layout/Header';
import { Dashboard } from './components/Dashboard/Dashboard';
import { TodoList } from './components/TodoList/TodoList';
import { PomodoroTimer } from './components/PomodoroTimer/PomodoroTimer';
import { Settings } from './components/Settings/Settings';

const AppContent: React.FC = () => {
  useKeyboardShortcuts();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Dashboard */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">
                Study Progress
              </h2>
              <Dashboard />
            </div>
          </div>

          {/* Todo List */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">
                Study Tasks
              </h2>
              <TodoList />
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      <PomodoroTimer />
      <Settings />
    </div>
  );
};

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;