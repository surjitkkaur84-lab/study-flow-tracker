import React from 'react';
import { CheckCircle, Clock, Target, Flame, BookOpen, TrendingUp } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { StatCard } from './StatCard';
import { ProgressChart } from './ProgressChart';

export const Dashboard: React.FC = () => {
  const { state } = useAppContext();
  const { tasks, stats, settings } = state;

  const completedTasks = tasks.filter(task => task.completed).length;
  const totalTasks = tasks.length;
  const totalStudySessions = tasks.reduce((sum, task) => sum + task.pomodorosCompleted, 0);
  const dailyGoalProgress = Math.round((stats.pomodorosCompleted / settings.studyGoal) * 100);

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Study Tasks"
          value={totalTasks}
          icon={<BookOpen size={24} />}
          color="blue"
        />
        <StatCard
          label="Completed Today"
          value={completedTasks}
          icon={<CheckCircle size={24} />}
          color="green"
        />
        <StatCard
          label="Study Sessions"
          value={totalStudySessions}
          icon={<Clock size={24} />}
          color="purple"
        />
        <StatCard
          label="Daily Goal"
          value={`${dailyGoalProgress}%`}
          icon={<Target size={24} />}
          color="red"
        />
      </div>

      {/* Progress Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ProgressChart
          completed={completedTasks}
          total={totalTasks}
          label="Today's Tasks"
        />
        <ProgressChart
          completed={stats.pomodorosCompleted}
          total={settings.studyGoal}
          label="Daily Study Goal"
        />
      </div>
      
      {/* Study Insights */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
        <div className="flex items-center mb-4">
          <TrendingUp className="text-blue-600 mr-2" size={20} />
          <h3 className="text-lg font-semibold text-gray-900">Study Insights</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.totalStudyTime || 0}</div>
            <div className="text-gray-600">Minutes Studied</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.dailyStreak}</div>
            <div className="text-gray-600">Day Streak</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.averageSessionLength}</div>
            <div className="text-gray-600">Avg Session (min)</div>
          </div>
        </div>
      </div>
    </div>
  );
};