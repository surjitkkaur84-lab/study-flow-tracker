import React from 'react';
import { Settings as SettingsIcon, Timer } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { StudyIcon } from '../common/StudyIcon';

export const Header: React.FC = () => {
  const { dispatch } = useAppContext();

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <StudyIcon size={32} />
            <div>
              <h1 className="text-xl font-bold text-gray-900">StudyFlow</h1>
              <p className="text-xs text-gray-500">Learn & Excel</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => dispatch({ type: 'TOGGLE_TIMER' })}
              className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="Open Timer (T)"
            >
              <Timer size={20} />
            </button>
            
            <button
              onClick={() => dispatch({ type: 'TOGGLE_SETTINGS' })}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              title="Settings (S)"
            >
              <SettingsIcon size={20} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};