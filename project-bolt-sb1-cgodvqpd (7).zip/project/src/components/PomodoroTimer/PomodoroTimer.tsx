import React from 'react';
import { X } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { TimerDisplay } from './TimerDisplay';
import { TimerControls } from './TimerControls';

export const PomodoroTimer: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { timer, isTimerOpen } = state;

  const handleClose = () => {
    dispatch({ type: 'CLOSE_TIMER' });
  };

  return (
    <Modal isOpen={isTimerOpen} onClose={handleClose} className="max-w-lg">
      <div className="relative">
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute -top-2 -right-2 z-10 p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
          aria-label="Close timer"
        >
          <X size={20} />
        </button>

        <div className="text-center py-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">
            Study Timer
          </h2>

          <TimerDisplay
            timeLeft={timer.timeLeft}
            currentPhase={timer.currentPhase}
            isRunning={timer.isRunning}
          />

          <div className="mt-8">
            <TimerControls />
          </div>
        </div>
      </div>
    </Modal>
  );
};