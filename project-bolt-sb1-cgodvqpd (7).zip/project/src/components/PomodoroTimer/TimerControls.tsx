import React from 'react';
import { Play, Pause, RotateCcw, Minus, Plus } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { useTimer } from '../../hooks/useTimer';
import { Button } from '../common/Button';

export const TimerControls: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { startTimer, pauseTimer, resetTimer } = useTimer();
  const { timer, settings } = state;

  const handleDurationChange = (type: 'work' | 'break', increment: boolean) => {
    const current = type === 'work' ? settings.studyDuration : settings.breakDuration;
    const newValue = increment ? current + 1 : Math.max(1, current - 1);
    
    dispatch({
      type: 'UPDATE_SETTINGS',
      payload: {
        [type === 'work' ? 'studyDuration' : 'breakDuration']: newValue,
      },
    });

    // Update timer if not running and same phase
    if (!timer.isRunning && 
        ((type === 'work' && timer.currentPhase === 'study') ||
         (type === 'break' && timer.currentPhase === 'break'))) {
      dispatch({ type: 'RESET_TIMER' });
    }
  };

  return (
    <div className="space-y-6">
      {/* Duration Controls */}
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Study Duration
          </label>
          <div className="flex items-center justify-center space-x-2">
            <button
              onClick={() => handleDurationChange('work', false)}
              className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded"
            >
              <Minus size={16} />
            </button>
            <span className="w-12 text-center font-medium">
              {settings.studyDuration}m
            </span>
            <button
              onClick={() => handleDurationChange('work', true)}
              className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded"
            >
              <Plus size={16} />
            </button>
          </div>
        </div>

        <div className="text-center">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Break Duration
          </label>
          <div className="flex items-center justify-center space-x-2">
            <button
              onClick={() => handleDurationChange('break', false)}
              className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded"
            >
              <Minus size={16} />
            </button>
            <span className="w-12 text-center font-medium">
              {settings.breakDuration}m
            </span>
            <button
              onClick={() => handleDurationChange('break', true)}
              className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded"
            >
              <Plus size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Controls */}
      <div className="flex justify-center space-x-3">
        <Button
          onClick={timer.isRunning ? pauseTimer : () => startTimer()}
          variant={timer.isRunning ? 'secondary' : 'primary'}
          size="lg"
          className="min-w-[120px]"
        >
          {timer.isRunning ? (
            <>
              <Pause size={18} className="mr-2" />
              Pause
            </>
          ) : (
            <>
              <Play size={18} className="mr-2" />
              {timer.currentPhase === 'study' ? 'Study' : 'Break'}
            </>
          )}
        </Button>

        <Button
          onClick={resetTimer}
          variant="secondary"
          size="lg"
        >
          <RotateCcw size={18} className="mr-2" />
          Reset
        </Button>
      </div>

      {/* Current Task Display */}
      {timer.activeTaskId && (
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Studying:</p>
          <p className="font-medium text-gray-900">
            {state.tasks.find(t => t.id === timer.activeTaskId)?.title || 'Unknown task'}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            Subject: {state.tasks.find(t => t.id === timer.activeTaskId)?.subject || 'General'}
          </p>
        </div>
      )}
      
      {/* Session Progress */}
      {timer.sessionCount > 0 && (
        <div className="text-center p-3 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-600">Study Sessions Completed: {timer.sessionCount}</p>
          <p className="text-xs text-blue-500">
            {timer.sessionCount % settings.longBreakInterval === 0 ? 'Time for a long break!' : `${settings.longBreakInterval - (timer.sessionCount % settings.longBreakInterval)} more until long break`}
          </p>
        </div>
      )}

      {/* Keyboard Shortcut Hint */}
      <div className="text-center text-xs text-gray-500">
        Press <kbd className="px-1 py-0.5 bg-gray-200 rounded">Space</kbd> to play/pause
      </div>
    </div>
  );
};