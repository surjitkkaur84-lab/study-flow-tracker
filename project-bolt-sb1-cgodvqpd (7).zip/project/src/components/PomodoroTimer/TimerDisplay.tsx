import React from 'react';
import { formatTime } from '../../utils/time';

interface TimerDisplayProps {
  timeLeft: number;
  currentPhase: 'study' | 'break' | 'long-break';
  isRunning: boolean;
}

export const TimerDisplay: React.FC<TimerDisplayProps> = ({ timeLeft, currentPhase, isRunning }) => {
  const radius = 90;
  const circumference = 2 * Math.PI * radius;
  const totalTime = currentPhase === 'study' ? 25 * 60 : currentPhase === 'long-break' ? 15 * 60 : 5 * 60;
  const progress = 1 - (timeLeft / totalTime);
  const strokeDashoffset = circumference - (progress * circumference);

  return (
    <div className="relative w-64 h-64 mx-auto">
      {/* Study timer background */}
      <div className={`
        absolute inset-0 rounded-full shadow-2xl transition-all duration-300
        ${currentPhase === 'study' 
          ? 'bg-gradient-to-br from-blue-400 to-blue-600 shadow-blue-300' 
          : currentPhase === 'long-break'
          ? 'bg-gradient-to-br from-purple-400 to-purple-600 shadow-purple-300'
          : 'bg-gradient-to-br from-green-400 to-green-600 shadow-green-300'
        }
      `}>
        {/* Book icon for study phase */}
        {currentPhase === 'study' && (
          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
            <div className="w-8 h-6 bg-white rounded-sm shadow-md flex items-center justify-center">
              <div className="text-xs text-blue-600">📚</div>
            </div>
          </div>
        )}
        
        {/* Coffee cup handle for break phase */}
        {currentPhase === 'break' && (
          <div className="absolute -right-6 top-1/2 transform -translate-y-1/2">
            <div className="w-6 h-12 border-4 border-green-400 rounded-r-full"></div>
          </div>
        )}
        
        {/* Meditation icon for long break */}
        {currentPhase === 'long-break' && (
          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
            <div className="w-8 h-6 bg-white rounded-full shadow-md flex items-center justify-center">
              <div className="text-xs text-purple-600">🧘</div>
            </div>
          </div>
        )}
      </div>

      {/* Progress circle */}
      <svg className="absolute inset-0 w-full h-full transform -rotate-90">
        <circle
          cx="50%"
          cy="50%"
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.2)"
          strokeWidth="4"
        />
        <circle
          cx="50%"
          cy="50%"
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.9)"
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className="transition-all duration-1000 ease-in-out"
        />
      </svg>

      {/* Time display */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
        <div className="text-4xl font-bold font-mono tracking-wider mb-2">
          {formatTime(timeLeft)}
        </div>
        <div className="text-sm uppercase tracking-wide opacity-90">
          {currentPhase === 'study' ? '📚 Study Time' : currentPhase === 'long-break' ? '🧘 Long Break' : '☕ Short Break'}
        </div>
        {isRunning && (
          <div className="mt-2 w-2 h-2 bg-white rounded-full animate-pulse"></div>
        )}
      </div>
    </div>
  );
};