import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { ThemeSelector } from './ThemeSelector';

export const Settings: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { settings, isSettingsOpen } = state;

  const handleClose = () => {
    dispatch({ type: 'TOGGLE_SETTINGS' });
  };

  const handleSettingChange = (key: keyof typeof settings, value: any) => {
    dispatch({
      type: 'UPDATE_SETTINGS',
      payload: { [key]: value },
    });
  };

  return (
    <Modal 
      isOpen={isSettingsOpen} 
      onClose={handleClose} 
      title="Settings"
      className="max-w-md"
    >
      <div className="space-y-6">
        {/* Timer Settings */}
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Timer Settings</h3>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Study Duration (minutes)
              </label>
              <input
                type="number"
                min="1"
                max="60"
                value={settings.studyDuration}
                onChange={(e) => handleSettingChange('studyDuration', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Break Duration (minutes)
              </label>
              <input
                type="number"
                min="1"
                max="30"
                value={settings.breakDuration}
                onChange={(e) => handleSettingChange('breakDuration', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Long Break Duration (minutes)
              </label>
              <input
                type="number"
                min="10"
                max="60"
                value={settings.longBreakDuration}
                onChange={(e) => handleSettingChange('longBreakDuration', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Long Break After (sessions)
              </label>
              <input
                type="number"
                min="2"
                max="8"
                value={settings.longBreakInterval}
                onChange={(e) => handleSettingChange('longBreakInterval', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Daily Study Goal (sessions)
            </label>
            <input
              type="number"
              min="1"
              max="20"
              value={settings.studyGoal}
              onChange={(e) => handleSettingChange('studyGoal', parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="space-y-3">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={settings.autoStartBreak}
                onChange={(e) => handleSettingChange('autoStartBreak', e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Automatically start break timer
              </span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={settings.autoStartLongBreak}
                onChange={(e) => handleSettingChange('autoStartLongBreak', e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Automatically start long break timer
              </span>
            </label>

            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={settings.soundEnabled}
                onChange={(e) => handleSettingChange('soundEnabled', e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Enable sound notifications
              </span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={settings.notificationsEnabled}
                onChange={(e) => handleSettingChange('notificationsEnabled', e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Enable browser notifications
              </span>
            </label>
          </div>
        </div>

        {/* Theme Settings */}
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Appearance</h3>
          <ThemeSelector />
        </div>

        {/* Keyboard Shortcuts */}
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Keyboard Shortcuts</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Start/Pause Timer</span>
              <kbd className="px-2 py-1 bg-gray-200 rounded text-xs">Space</kbd>
            </div>
            <div className="flex justify-between">
              <span>Open Settings</span>
              <kbd className="px-2 py-1 bg-gray-200 rounded text-xs">S</kbd>
            </div>
            <div className="flex justify-between">
              <span>Toggle Timer</span>
              <kbd className="px-2 py-1 bg-gray-200 rounded text-xs">T</kbd>
            </div>
            <div className="flex justify-between">
              <span>Close Modal</span>
              <kbd className="px-2 py-1 bg-gray-200 rounded text-xs">Escape</kbd>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};