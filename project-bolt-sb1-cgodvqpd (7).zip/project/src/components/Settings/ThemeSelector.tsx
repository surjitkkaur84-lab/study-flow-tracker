import React from 'react';
import { Theme } from '../../types';
import { useAppContext } from '../../context/AppContext';

const themes = [
  { id: 'academic' as Theme, name: 'Academic Blue', primary: 'bg-blue-500', secondary: 'bg-blue-100' },
  { id: 'forest' as Theme, name: 'Forest Green', primary: 'bg-green-500', secondary: 'bg-green-100' },
  { id: 'ocean' as Theme, name: 'Ocean Teal', primary: 'bg-teal-500', secondary: 'bg-teal-100' },
  { id: 'midnight' as Theme, name: 'Midnight Dark', primary: 'bg-gray-800', secondary: 'bg-gray-100' },
];

export const ThemeSelector: React.FC = () => {
  const { state, dispatch } = useAppContext();

  const handleThemeChange = (theme: Theme) => {
    dispatch({
      type: 'UPDATE_SETTINGS',
      payload: { theme },
    });
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-3">
        Color Theme
      </label>
      <div className="grid grid-cols-1 gap-3">
        {themes.map((theme) => (
          <button
            key={theme.id}
            onClick={() => handleThemeChange(theme.id)}
            className={`
              flex items-center space-x-3 p-3 rounded-lg border-2 transition-all duration-200
              ${state.settings.theme === theme.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
              }
            `}
          >
            <div className="flex space-x-2">
              <div className={`w-4 h-4 rounded-full ${theme.primary}`}></div>
              <div className={`w-4 h-4 rounded-full ${theme.secondary}`}></div>
            </div>
            <span className="font-medium text-gray-900">{theme.name}</span>
            {state.settings.theme === theme.id && (
              <div className="ml-auto">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};