import React, { useState } from 'react';
import { Plus, Calendar, BookOpen, Target } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { Button } from '../common/Button';

const studyTypes = [
  { value: 'reading', label: '📖 Reading', icon: '📖' },
  { value: 'practice', label: '✏️ Practice', icon: '✏️' },
  { value: 'research', label: '🔍 Research', icon: '🔍' },
  { value: 'review', label: '📝 Review', icon: '📝' },
  { value: 'assignment', label: '📋 Assignment', icon: '📋' },
  { value: 'exam-prep', label: '🎯 Exam Prep', icon: '🎯' },
];

const subjects = [
  'Mathematics', 'Computer Science', 'Physics', 'Chemistry', 'Biology',
  'Literature', 'History', 'Psychology', 'Economics', 'Philosophy',
  'Engineering', 'Medicine', 'Law', 'Business', 'Art', 'Music', 'Other'
];
export const AddTaskForm: React.FC = () => {
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [studyType, setStudyType] = useState('reading');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [estimatedPomodoros, setEstimatedPomodoros] = useState<number | ''>('');
  const [dueDate, setDueDate] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const { dispatch } = useAppContext();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim()) {
      dispatch({ 
        type: 'ADD_TASK', 
        payload: { 
          title: title.trim(),
          subject: subject || 'General',
          priority,
          studyType,
          difficulty,
          estimatedPomodoros: estimatedPomodoros ? Number(estimatedPomodoros) : undefined,
          dueDate: dueDate ? new Date(dueDate).getTime() : undefined,
        } 
      });
      setTitle('');
      setSubject('');
      setPriority('medium');
      setStudyType('reading');
      setDifficulty('medium');
      setEstimatedPomodoros('');
      setDueDate('');
      setIsExpanded(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setTitle('');
      setSubject('');
      setPriority('medium');
      setStudyType('reading');
      setDifficulty('medium');
      setEstimatedPomodoros('');
      setDueDate('');
      setIsExpanded(false);
    }
  };

  if (!isExpanded) {
    return (
      <button
        onClick={() => setIsExpanded(true)}
        className="w-full p-4 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-blue-300 hover:text-blue-500 transition-colors duration-200 flex items-center justify-center space-x-2"
      >
        <Plus size={20} />
        <span>Add a new study task</span>
      </button>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg border-2 border-blue-200 p-6 space-y-4">
      <div className="space-y-4">
        {/* Task Title */}
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="What do you need to study?"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          autoFocus
        />
        
        {/* Subject and Study Type */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <BookOpen size={16} className="inline mr-1" />
              Subject
            </label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select subject...</option>
              {subjects.map(subj => (
                <option key={subj} value={subj}>{subj}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Study Type
            </label>
            <select
              value={studyType}
              onChange={(e) => setStudyType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {studyTypes.map(type => (
                <option key={type.value} value={type.value}>{type.label}</option>
              ))}
            </select>
          </div>
        </div>
        
        {/* Priority, Difficulty, and Estimated Time */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high')}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="low">🟢 Low</option>
              <option value="medium">🟡 Medium</option>
              <option value="high">🔴 High</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Difficulty
            </label>
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as 'easy' | 'medium' | 'hard')}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="easy">⭐ Easy</option>
              <option value="medium">⭐⭐ Medium</option>
              <option value="hard">⭐⭐⭐ Hard</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Target size={16} className="inline mr-1" />
              Est. Sessions
            </label>
            <input
              type="number"
              min="1"
              max="20"
              value={estimatedPomodoros}
              onChange={(e) => setEstimatedPomodoros(e.target.value ? Number(e.target.value) : '')}
              placeholder="Optional"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
        
        {/* Due Date */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <Calendar size={16} className="inline mr-1" />
            Due Date (Optional)
          </label>
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="flex space-x-3 pt-2">
        <Button type="submit" disabled={!title.trim()}>
          Add Study Task
        </Button>
        <Button 
          type="button" 
          variant="secondary" 
          onClick={() => {
            setTitle('');
            setSubject('');
            setPriority('medium');
            setStudyType('reading');
            setDifficulty('medium');
            setEstimatedPomodoros('');
            setDueDate('');
            setIsExpanded(false);
          }}
        >
          Cancel
        </Button>
      </div>
    </form>
  );
};