import React, { useState } from 'react';
import { Check, Edit2, Trash2, GripVertical, Clock, Calendar, BookOpen } from 'lucide-react';
import { Task } from '../../types';
import { useAppContext } from '../../context/AppContext';
import { useDragAndDrop } from '../../hooks/useDragAndDrop';
import { StudyIcon } from '../common/StudyIcon';

interface TaskItemProps {
  task: Task;
  index: number;
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'high': return 'text-red-600 bg-red-50';
    case 'medium': return 'text-yellow-600 bg-yellow-50';
    case 'low': return 'text-green-600 bg-green-50';
    default: return 'text-gray-600 bg-gray-50';
  }
};

const getDifficultyStars = (difficulty: string) => {
  switch (difficulty) {
    case 'easy': return '⭐';
    case 'medium': return '⭐⭐';
    case 'hard': return '⭐⭐⭐';
    default: return '⭐⭐';
  }
};

const getStudyTypeIcon = (studyType: string) => {
  switch (studyType) {
    case 'reading': return '📖';
    case 'practice': return '✏️';
    case 'research': return '🔍';
    case 'review': return '📝';
    case 'assignment': return '📋';
    case 'exam-prep': return '🎯';
    default: return '📚';
  }
};
export const TaskItem: React.FC<TaskItemProps> = ({ task, index }) => {
  const { dispatch } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(task.title);
  const { handleDragStart, handleDragEnd, handleDragOver, handleDrop } = useDragAndDrop();

  const isOverdue = task.dueDate && task.dueDate < Date.now() && !task.completed;
  const isDueSoon = task.dueDate && task.dueDate < Date.now() + (24 * 60 * 60 * 1000) && !task.completed;

  const handleEdit = () => {
    if (isEditing) {
      if (editTitle.trim()) {
        dispatch({
          type: 'UPDATE_TASK',
          payload: { id: task.id, updates: { title: editTitle.trim() } },
        });
      }
      setIsEditing(false);
    } else {
      setIsEditing(true);
    }
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      handleEdit();
    } else if (event.key === 'Escape') {
      setEditTitle(task.title);
      setIsEditing(false);
    }
  };

  const handleStartTimer = () => {
    dispatch({ type: 'START_TIMER', payload: { taskId: task.id } });
  };

  return (
    <div
      className={`
        group relative bg-white rounded-lg border-2 transition-all duration-200 hover:shadow-md
        ${task.completed 
          ? 'border-green-200 bg-green-50' 
          : isOverdue 
          ? 'border-red-200 bg-red-50' 
          : isDueSoon 
          ? 'border-yellow-200 bg-yellow-50' 
          : 'border-gray-200'
        }
        animate-in fade-in-0 slide-in-from-left-1 duration-300
      `}
      draggable={!isEditing}
      onDragStart={handleDragStart(index)}
      onDragEnd={handleDragEnd}
      onDragOver={handleDragOver}
      onDrop={handleDrop(index)}
    >
      <div className="flex items-center p-4">
        {/* Drag Handle */}
        <div className="flex-shrink-0 mr-3 cursor-grab active:cursor-grabbing opacity-0 group-hover:opacity-100 transition-opacity">
          <GripVertical size={16} className="text-gray-400" />
        </div>

        {/* Checkbox */}
        <button
          onClick={() => dispatch({ type: 'TOGGLE_TASK', payload: { id: task.id } })}
          className={`
            flex-shrink-0 w-6 h-6 mr-3 rounded border-2 flex items-center justify-center transition-all duration-200
            ${task.completed 
              ? 'bg-green-500 border-green-500 text-white' 
              : 'border-gray-300 hover:border-blue-500 hover:bg-blue-50'
            }
          `}
        >
          {task.completed && <Check size={14} />}
        </button>

        {/* Task Title */}
        <div className="flex-1 min-w-0">
          {/* Subject and Study Type */}
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xs font-medium text-blue-600 bg-blue-100 px-2 py-0.5 rounded-full">
              <BookOpen size={10} className="inline mr-1" />
              {task.subject}
            </span>
            <span className="text-xs text-gray-500">
              {getStudyTypeIcon(task.studyType)} {task.studyType}
            </span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${getPriorityColor(task.priority)}`}>
              {task.priority}
            </span>
          </div>
          
          {/* Task Title */}
          {isEditing ? (
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              onBlur={handleEdit}
              onKeyDown={handleKeyPress}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              autoFocus
            />
          ) : (
            <span 
              className={`
                text-sm font-medium transition-all duration-200
                ${task.completed 
                  ? 'text-gray-500 line-through' 
                  : 'text-gray-900'
                }
              `}
            >
              {task.title}
            </span>
          )}
          
          {/* Task Metadata */}
          <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
            {task.pomodorosCompleted > 0 && (
              <span className="flex items-center">
                <Clock size={12} className="mr-1" />
                {task.pomodorosCompleted}/{task.estimatedPomodoros || '?'} sessions
              </span>
            )}
            <span>{getDifficultyStars(task.difficulty)}</span>
            {task.dueDate && (
              <span className={`flex items-center ${isOverdue ? 'text-red-600' : isDueSoon ? 'text-yellow-600' : ''}`}>
                <Calendar size={12} className="mr-1" />
                {new Date(task.dueDate).toLocaleDateString()}
              </span>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
          {!task.completed && (
            <button
              onClick={handleStartTimer}
              className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-full transition-colors"
              title="Start Study Session"
            >
              <StudyIcon size={18} />
            </button>
          )}
          
          <button
            onClick={handleEdit}
            className="p-1.5 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
            title="Edit Task"
          >
            <Edit2 size={14} />
          </button>

          <button
            onClick={() => dispatch({ type: 'DELETE_TASK', payload: { id: task.id } })}
            className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
            title="Delete Task"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};