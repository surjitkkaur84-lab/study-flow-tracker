import React from 'react';

interface StudyIconProps {
  size?: number;
  className?: string;
}

export const StudyIcon: React.FC<StudyIconProps> = ({ size = 24, className = '' }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      className={className}
    >
      {/* Book base */}
      <path 
        d="M4 6c0-1.1.9-2 2-2h12c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H6c-1.1 0-2-.9-2-2V6z" 
        fill="currentColor"
        className="text-blue-500"
      />
      {/* Book spine */}
      <path 
        d="M6 4v16" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round"
        className="text-blue-700"
      />
      {/* Pages */}
      <path 
        d="M9 8h6M9 12h6M9 16h4" 
        stroke="white" 
        strokeWidth="1.5" 
        strokeLinecap="round"
      />
      {/* Study indicator (small clock) */}
      <circle 
        cx="18" 
        cy="6" 
        r="3" 
        fill="currentColor"
        className="text-green-500"
      />
      <path 
        d="M18 4v2l1 1" 
        stroke="white" 
        strokeWidth="1" 
        strokeLinecap="round"
      />
    </svg>
  );
};