import React from 'react';

interface TomatoIconProps {
  size?: number;
  className?: string;
}

export const TomatoIcon: React.FC<TomatoIconProps> = ({ size = 24, className = '' }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      className={className}
    >
      {/* Tomato body */}
      <path 
        d="M6 10c0-4 2.5-6 6-6s6 2 6 6c0 6-2.5 10-6 10s-6-4-6-10z" 
        fill="currentColor"
        className="text-red-500"
      />
      {/* Tomato stem */}
      <path 
        d="M10 4c0-1 1-2 2-2s2 1 2 2" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round"
        className="text-green-500"
        fill="none"
      />
      {/* Tomato leaves */}
      <path 
        d="M11 4c-1-1-2-1-3 0M13 4c1-1 2-1 3 0" 
        stroke="currentColor" 
        strokeWidth="1.5" 
        strokeLinecap="round"
        className="text-green-500"
        fill="none"
      />
    </svg>
  );
};