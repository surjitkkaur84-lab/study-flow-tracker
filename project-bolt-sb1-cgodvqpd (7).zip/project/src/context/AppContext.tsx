import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { Task, TimerState, Settings, Stats } from '../types';
import { loadFromStorage, saveToStorage } from '../utils/storage';

interface AppState {
  tasks: Task[];
  timer: TimerState;
  settings: Settings;
  stats: Stats;
  isSettingsOpen: boolean;
  isTimerOpen: boolean;
}

type AppAction =
  | { type: 'ADD_TASK'; payload: { title: string; subject?: string; priority?: 'low' | 'medium' | 'high'; studyType?: string; difficulty?: string; estimatedPomodoros?: number; dueDate?: number } }
  | { type: 'UPDATE_TASK'; payload: { id: string; updates: Partial<Task> } }
  | { type: 'DELETE_TASK'; payload: { id: string } }
  | { type: 'REORDER_TASKS'; payload: { dragIndex: number; hoverIndex: number } }
  | { type: 'TOGGLE_TASK'; payload: { id: string } }
  | { type: 'START_TIMER'; payload: { taskId?: string } }
  | { type: 'PAUSE_TIMER' }
  | { type: 'RESET_TIMER' }
  | { type: 'TICK_TIMER' }
  | { type: 'COMPLETE_PHASE' }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<Settings> }
  | { type: 'TOGGLE_SETTINGS' }
  | { type: 'TOGGLE_TIMER' }
  | { type: 'CLOSE_TIMER' }
  | { type: 'UPDATE_STATS'; payload: Partial<Stats> }
  | { type: 'ADD_STUDY_SESSION'; payload: { taskId: string; duration: number; subject: string; studyType: string } }
  | { type: 'LOAD_STATE'; payload: Partial<AppState> };

const defaultSettings: Settings = {
  studyDuration: 25,
  breakDuration: 5,
  longBreakDuration: 15,
  longBreakInterval: 4,
  autoStartBreak: true,
  autoStartLongBreak: false,
  theme: 'academic',
  soundEnabled: true,
  notificationsEnabled: true,
  studyGoal: 8,
};

const initialState: AppState = {
  tasks: [],
  timer: {
    isRunning: false,
    timeLeft: defaultSettings.studyDuration * 60,
    currentPhase: 'study',
    sessionCount: 0,
  },
  settings: defaultSettings,
  stats: {
    tasksCompleted: 0,
    studySessionsCompleted: 0,
    pomodorosCompleted: 0,
    dailyStreak: 0,
    weeklyGoalProgress: 0,
    totalTasks: 0,
    totalStudyTime: 0,
    averageSessionLength: 25,
    subjectStats: {},
  },
  isSettingsOpen: false,
  isTimerOpen: false,
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'ADD_TASK':
      const newTask: Task = {
        id: Date.now().toString(),
        title: action.payload.title,
        subject: action.payload.subject || 'General',
        priority: action.payload.priority || 'medium',
        studyType: action.payload.studyType || 'reading',
        difficulty: action.payload.difficulty || 'medium',
        completed: false,
        createdAt: Date.now(),
        pomodorosCompleted: 0,
        estimatedPomodoros: action.payload.estimatedPomodoros,
        dueDate: action.payload.dueDate,
      };
      return {
        ...state,
        tasks: [...state.tasks, newTask],
        stats: { ...state.stats, totalTasks: state.stats.totalTasks + 1 },
      };

    case 'UPDATE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(task =>
          task.id === action.payload.id
            ? { ...task, ...action.payload.updates }
            : task
        ),
      };

    case 'DELETE_TASK':
      const taskToDelete = state.tasks.find(t => t.id === action.payload.id);
      return {
        ...state,
        tasks: state.tasks.filter(task => task.id !== action.payload.id),
        stats: {
          ...state.stats,
          totalTasks: state.stats.totalTasks - 1,
          tasksCompleted: taskToDelete?.completed 
            ? state.stats.tasksCompleted - 1 
            : state.stats.tasksCompleted,
        },
      };

    case 'TOGGLE_TASK':
      const task = state.tasks.find(t => t.id === action.payload.id);
      if (!task) return state;
      
      const isCompleting = !task.completed;
      return {
        ...state,
        tasks: state.tasks.map(t =>
          t.id === action.payload.id
            ? {
                ...t,
                completed: !t.completed,
                completedAt: isCompleting ? Date.now() : undefined,
              }
            : t
        ),
        stats: {
          ...state.stats,
          tasksCompleted: isCompleting
            ? state.stats.tasksCompleted + 1
            : state.stats.tasksCompleted - 1,
        },
      };

    case 'REORDER_TASKS':
      const { dragIndex, hoverIndex } = action.payload;
      const draggedTask = state.tasks[dragIndex];
      const newTasks = [...state.tasks];
      newTasks.splice(dragIndex, 1);
      newTasks.splice(hoverIndex, 0, draggedTask);
      return { ...state, tasks: newTasks };

    case 'START_TIMER':
      return {
        ...state,
        timer: {
          ...state.timer,
          isRunning: true,
          activeTaskId: action.payload.taskId,
        },
        isTimerOpen: true,
      };

    case 'PAUSE_TIMER':
      return {
        ...state,
        timer: { ...state.timer, isRunning: false },
      };

    case 'RESET_TIMER':
      return {
        ...state,
        timer: {
          ...state.timer,
          isRunning: false,
          timeLeft: state.timer.currentPhase === 'study'
            ? state.settings.studyDuration * 60
            : state.timer.currentPhase === 'long-break'
            ? state.settings.longBreakDuration * 60
            : state.settings.breakDuration * 60,
        },
      };

    case 'TICK_TIMER':
      return {
        ...state,
        timer: {
          ...state.timer,
          timeLeft: Math.max(0, state.timer.timeLeft - 1),
        },
      };

    case 'COMPLETE_PHASE':
      const isStudyPhase = state.timer.currentPhase === 'study';
      const newSessionCount = isStudyPhase ? state.timer.sessionCount + 1 : state.timer.sessionCount;
      const shouldTakeLongBreak = newSessionCount > 0 && newSessionCount % state.settings.longBreakInterval === 0;
      
      const newStats = isStudyPhase
        ? { 
            ...state.stats, 
            pomodorosCompleted: state.stats.pomodorosCompleted + 1,
            studySessionsCompleted: state.stats.studySessionsCompleted + 1,
            totalStudyTime: state.stats.totalStudyTime + state.settings.studyDuration,
          }
        : state.stats;

      let updatedTasks = state.tasks;
      if (isStudyPhase && state.timer.activeTaskId) {
        updatedTasks = state.tasks.map(task =>
          task.id === state.timer.activeTaskId
            ? { ...task, pomodorosCompleted: task.pomodorosCompleted + 1 }
            : task
        );
      }

      const getNextPhase = () => {
        if (isStudyPhase) {
          return shouldTakeLongBreak && state.settings.autoStartLongBreak ? 'long-break' : 'break';
        }
        return 'study';
      };

      const getNextDuration = () => {
        const nextPhase = getNextPhase();
        if (nextPhase === 'study') return state.settings.studyDuration * 60;
        if (nextPhase === 'long-break') return state.settings.longBreakDuration * 60;
        return state.settings.breakDuration * 60;
      };
      return {
        ...state,
        tasks: updatedTasks,
        timer: {
          isRunning: (state.settings.autoStartBreak && isStudyPhase) || (shouldTakeLongBreak && state.settings.autoStartLongBreak),
          timeLeft: getNextDuration(),
          currentPhase: getNextPhase(),
          activeTaskId: isStudyPhase ? undefined : state.timer.activeTaskId,
          sessionCount: newSessionCount,
        },
        stats: newStats,
      };

    case 'UPDATE_SETTINGS':
      return {
        ...state,
        settings: { ...state.settings, ...action.payload },
      };

    case 'TOGGLE_SETTINGS':
      return { ...state, isSettingsOpen: !state.isSettingsOpen };

    case 'TOGGLE_TIMER':
      return { ...state, isTimerOpen: !state.isTimerOpen };

    case 'CLOSE_TIMER':
      return { 
        ...state, 
        isTimerOpen: false,
        timer: { ...state.timer, isRunning: false },
      };

    case 'UPDATE_STATS':
      return {
        ...state,
        stats: { ...state.stats, ...action.payload },
      };

    case 'LOAD_STATE':
      return { ...state, ...action.payload };

    default:
      return state;
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load initial state from localStorage
  useEffect(() => {
    const savedTasks = loadFromStorage<Task[]>('pomodoro-tasks', []);
    const savedSettings = loadFromStorage<Settings>('pomodoro-settings', defaultSettings);
    const savedStats = loadFromStorage<Stats>('pomodoro-stats', {
      tasksCompleted: 0,
      pomodorosCompleted: 0,
      dailyStreak: 0,
      totalTasks: 0,
    });

    dispatch({
      type: 'LOAD_STATE',
      payload: {
        tasks: savedTasks,
        settings: savedSettings,
        stats: savedStats,
        timer: {
          isRunning: false,
          timeLeft: savedSettings.studyDuration * 60,
          currentPhase: 'study',
          sessionCount: 0,
        },
      },
    });
  }, []);

  // Save state to localStorage
  useEffect(() => {
    saveToStorage('pomodoro-tasks', state.tasks);
    saveToStorage('pomodoro-settings', state.settings);
    saveToStorage('pomodoro-stats', state.stats);
  }, [state.tasks, state.settings, state.stats]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};