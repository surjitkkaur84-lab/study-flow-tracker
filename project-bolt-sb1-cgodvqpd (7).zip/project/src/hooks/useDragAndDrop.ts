import { useRef, DragEvent } from 'react';
import { useAppContext } from '../context/AppContext';

export const useDragAndDrop = () => {
  const { dispatch } = useAppContext();
  const draggedIndex = useRef<number | null>(null);

  const handleDragStart = (index: number) => (event: DragEvent) => {
    draggedIndex.current = index;
    event.dataTransfer.effectAllowed = 'move';
    
    // Add some visual feedback
    const target = event.currentTarget as HTMLElement;
    target.style.opacity = '0.5';
  };

  const handleDragEnd = (event: DragEvent) => {
    const target = event.currentTarget as HTMLElement;
    target.style.opacity = '1';
    draggedIndex.current = null;
  };

  const handleDragOver = (event: DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (dropIndex: number) => (event: DragEvent) => {
    event.preventDefault();
    
    if (draggedIndex.current !== null && draggedIndex.current !== dropIndex) {
      dispatch({
        type: 'REORDER_TASKS',
        payload: {
          dragIndex: draggedIndex.current,
          hoverIndex: dropIndex,
        },
      });
    }
  };

  return {
    handleDragStart,
    handleDragEnd,
    handleDragOver,
    handleDrop,
  };
};