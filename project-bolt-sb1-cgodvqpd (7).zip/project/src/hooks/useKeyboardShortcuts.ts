import { useEffect } from 'react';
import { useAppContext } from '../context/AppContext';

export const useKeyboardShortcuts = () => {
  const { state, dispatch } = useAppContext();

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      // Don't trigger shortcuts if user is typing in an input
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (event.key.toLowerCase()) {
        case ' ':
          event.preventDefault();
          if (state.timer.isRunning) {
            dispatch({ type: 'PAUSE_TIMER' });
          } else if (state.isTimerOpen) {
            dispatch({ type: 'START_TIMER', payload: {} });
          }
          break;
        case 's':
          event.preventDefault();
          dispatch({ type: 'TOGGLE_SETTINGS' });
          break;
        case 't':
          event.preventDefault();
          dispatch({ type: 'TOGGLE_TIMER' });
          break;
        case 'escape':
          if (state.isSettingsOpen) {
            dispatch({ type: 'TOGGLE_SETTINGS' });
          } else if (state.isTimerOpen) {
            dispatch({ type: 'CLOSE_TIMER' });
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [state.timer.isRunning, state.isTimerOpen, state.isSettingsOpen, dispatch]);
};