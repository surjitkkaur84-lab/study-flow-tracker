import { useEffect, useRef } from 'react';
import { useAppContext } from '../context/AppContext';
import { soundManager } from '../utils/sound';

export const useTimer = () => {
  const { state, dispatch } = useAppContext();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (state.timer.isRunning) {
      intervalRef.current = setInterval(() => {
        dispatch({ type: 'TICK_TIMER' });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [state.timer.isRunning, dispatch]);

  useEffect(() => {
    if (state.timer.timeLeft === 0 && state.timer.isRunning) {
      // Play completion sound
      if (state.settings.soundEnabled) {
        if (state.timer.currentPhase === 'work') {
          soundManager.playWorkComplete();
        } else {
          soundManager.playBreakComplete();
        }
      }
      
      dispatch({ type: 'COMPLETE_PHASE' });
    }
  }, [state.timer.timeLeft, state.timer.isRunning, state.timer.currentPhase, state.settings.soundEnabled, dispatch]);

  // Play tick sound in last 10 seconds
  useEffect(() => {
    if (state.timer.isRunning && state.timer.timeLeft <= 10 && state.timer.timeLeft > 0 && state.settings.soundEnabled) {
      soundManager.playTick();
    }
  }, [state.timer.timeLeft, state.timer.isRunning, state.settings.soundEnabled]);

  return {
    startTimer: (taskId?: string) => dispatch({ type: 'START_TIMER', payload: { taskId } }),
    pauseTimer: () => dispatch({ type: 'PAUSE_TIMER' }),
    resetTimer: () => dispatch({ type: 'RESET_TIMER' }),
  };
};