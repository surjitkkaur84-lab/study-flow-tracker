export interface Task {
  id: string;
  title: string;
  subject?: string;
  priority: 'low' | 'medium' | 'high';
  studyType: 'reading' | 'practice' | 'research' | 'review' | 'assignment' | 'exam-prep';
  difficulty: 'easy' | 'medium' | 'hard';
  completed: boolean;
  createdAt: number;
  completedAt?: number;
  pomodorosCompleted: number;
  estimatedPomodoros?: number;
  dueDate?: number;
  notes?: string;
}

export interface TimerState {
  isRunning: boolean;
  timeLeft: number;
  currentPhase: 'study' | 'break' | 'long-break';
  activeTaskId?: string;
  sessionCount: number;
}

export interface Settings {
  studyDuration: number; // in minutes
  breakDuration: number; // in minutes
  longBreakDuration: number; // in minutes
  longBreakInterval: number; // after how many study sessions
  autoStartBreak: boolean;
  autoStartLongBreak: boolean;
  theme: 'academic' | 'forest' | 'midnight' | 'ocean';
  soundEnabled: boolean;
  notificationsEnabled: boolean;
  studyGoal: number; // daily pomodoros target
}

export interface Stats {
  tasksCompleted: number;
  studySessionsCompleted: number;
  pomodorosCompleted: number;
  dailyStreak: number;
  weeklyGoalProgress: number;
  totalTasks: number;
  totalStudyTime: number; // in minutes
  averageSessionLength: number;
  subjectStats: Record<string, { sessions: number; timeSpent: number }>;
}

export type Theme = 'academic' | 'forest' | 'midnight' | 'ocean';

export interface StudySession {
  id: string;
  taskId: string;
  startTime: number;
  endTime: number;
  duration: number;
  subject: string;
  studyType: string;
  completed: boolean;
}