/**
 * Sound utilities for timer notifications
 */

class SoundManager {
  private audioContext: AudioContext | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'AudioContext' in window) {
      this.audioContext = new AudioContext();
    }
  }

  private createBeep(frequency: number, duration: number): void {
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.frequency.value = frequency;
    oscillator.type = 'sine';

    gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);

    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration);
  }

  playWorkComplete(): void {
    // Play a pleasant completion sound
    this.createBeep(523.25, 0.2); // C5
    setTimeout(() => this.createBeep(659.25, 0.2), 100); // E5
    setTimeout(() => this.createBeep(783.99, 0.4), 200); // G5
  }

  playBreakComplete(): void {
    // Play a gentle return-to-work sound
    this.createBeep(440, 0.3); // A4
    setTimeout(() => this.createBeep(349.23, 0.3), 150); // F4
  }

  playTick(): void {
    // Subtle tick sound for the last 10 seconds
    this.createBeep(800, 0.05);
  }
}

export const soundManager = new SoundManager();